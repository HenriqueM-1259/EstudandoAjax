const bodyParser = require('body-parser')
const express = require('express')
const req = require('express/lib/request')
const { get } = require('express/lib/response')
const { stat } = require('fs')
const app = express()
const fs = require('fs').promises;


app.use(express.static('.'))
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())

const multer = require('multer')

const storage = multer.diskStorage({
    destination: function(req,file, callback){
        callback(null, './upload')

    },
    filename:function(req, file, callback){
        callback(null, `${Date.now()}_${file.originalname}`)
    }
})
 

const upload = multer({storage}).single('arquivo')

app.post('/upload',(req,res) => {
    upload(req,res,err => {
        if(err) {
            return res.end("ocorreu um erro")
        }
        res.end("concluido")

    })
})
/*
app.get('/upload', (req, res)=>{
    get(req,res,err =>{
        if(err){
            return res.end("ocorreu um erro")
        }
        res.end("concluido")
        async function ListarVideos(diretorio, arquivo){
            if(!arquivo)
                arquivo = [];

            let listaDeVideo = await fs.readdir(diretorio);
           for(let k in listaDeVideo){
               let start = await fs.stat(diretorio+'/'+listaDeVideo[k]);
               if(stat.isDirectory())
                await listaDeVideo(diretorio+'/'+listaDeVideo[k], arquivo)
                else
                arquivo.pus(diretorio+'/'+listaDeVideo[k]);
           }
           return arquivo;
        }

        async function test() {
            let arquivos = await ListarVideos('./upload'); // coloque o caminho do seu diretorio
            console.log(arquivos);
            return arquivos;
        }
        test();

    })
})
*/
app.listen(8080,() => console.log('executando'))

